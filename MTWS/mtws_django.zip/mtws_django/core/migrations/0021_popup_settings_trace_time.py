from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0020_access_control'),
    ]

    operations = [
        migrations.AddField(
            model_name='popupsettings',
            name='trace_time',
            field=models.PositiveSmallIntegerField(default=6, verbose_name='弹窗追溯时间（小时）'),
        ),
    ]
