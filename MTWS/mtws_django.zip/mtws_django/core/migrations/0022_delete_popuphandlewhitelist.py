from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0021_popup_settings_trace_time'),
    ]

    operations = [
        migrations.DeleteModel(
            name='PopupHandleWhitelist',
        ),
    ]
