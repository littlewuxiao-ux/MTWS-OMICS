(function () {
            function applyViewCssOnly(view) {
              var allowed = { home: 1, monitor: 1, action: 1, analysis: 1 };
              if (!allowed[view]) view = "home";
              document.body.setAttribute("data-view", view);
            }
            function go(view) {
              if (!view) return;
              try {
                if (typeof window.__wbNavigateToView === "function") {
                  window.__wbNavigateToView(view);
                  return;
                }
              } catch (_) {}
              applyViewCssOnly(view);
              try {
                var u = new URL(window.location.href);
                if (view === "home") u.searchParams.delete("view");
                else u.searchParams.set("view", view);
                history.replaceState({ view: view }, "", u);
              } catch (_) {
                /* ignore */
              }
            }
            // 首屏：若地址已带 ?view=，先切屏，避免等主脚本
            try {
              var q = new URLSearchParams(window.location.search).get("view");
              if (q) applyViewCssOnly(String(q).toLowerCase());
            } catch (_) {}
            document.getElementById("homeLauncher")?.addEventListener(
              "click",
              function (e) {
                var t = e.target && e.target.closest ? e.target.closest("[data-launch-view]") : null;
                if (!t) return;
                e.preventDefault();
                e.stopPropagation();
                go(t.getAttribute("data-launch-view"));
              },
              true
            );
            window.__wbBootstrapGo = go;
          })();
window.__WB_CHECKLIST_EMBEDDED__ = {"version":2,"source":"气象服务席检查单工作项.xlsx","exportedAt":"2026-05-06T23:32:44","shifts":{"day":{"id":"day","label":"每日 08:30–18:00","items":[{"serial":1,"title":"发布鄂州机场未来三天专项天气预报","deadline":"10:00"},{"serial":2,"title":"检查06UTC低空重要天气预告图","deadline":"10:50"},{"serial":3,"title":"检查12UTC中高层重要天气预告图、高空风和温度预告图","deadline":"13:50"},{"serial":4,"title":"发布未来24小时天气预报","deadline":"15:00"},{"serial":5,"title":"通报全国雷达拼图至丰声“航空气象信息通报群”，并通知运行控制带班","deadline":"16:10"},{"serial":6,"title":"检查12UTC低空重要天气预告图","deadline":"16:50"},{"serial":7,"title":"发布未来48小时区域雷雨/降雪/冻雨天气警报【视情】","deadline":"18:00"},{"serial":8,"title":"提供航线气象信息说明【视情】","deadline":"18:00"},{"serial":9,"title":"发布次日国际主备降机场天气预报【视情】","deadline":"18:00"},{"serial":10,"title":"发布未来一周天气预报【周五】","deadline":"18:00"},{"serial":11,"title":"发布假日天气展望","deadline":"18:00"},{"serial":12,"title":"制作并讲解天气分析材料，同步维护飞行运作网简报","deadline":"18:00"},{"serial":13,"title":"运行区域内热带气旋和火山动态","deadline":"18:00"},{"serial":14,"title":"深圳机场出现手册中规定的预警天气类型时，在丰声群“航空气象信息通报群”和“安技胡同群”通报","deadline":"18:00"},{"serial":15,"title":"气象席位预报质量评定","deadline":"18:00"}]},"night":{"id":"night","label":"每日 17:30–次日 03:30","items":[{"serial":1,"title":"检查18UTC中高层重要天气预告图、高空风和温度预告图","deadline":"19:50"},{"serial":2,"title":"发布未来8小时天气预报","deadline":"20:00"},{"serial":3,"title":"通报全国雷达拼图至丰声“航空气象信息通报群”，并通知运行控制带班","deadline":"21:10"},{"serial":4,"title":"检查18UTC低空重要天气预告图","deadline":"22:50"},{"serial":5,"title":"通报全国低能见度实况图至丰声“航空气象信息通报群”，并向签派放行带班席提供00-09时天气梳理结果","deadline":"00:00"},{"serial":6,"title":"检查00UTC中高层重要天气预告图、高空风和温度预告图","deadline":"01:50"},{"serial":7,"title":"转存中央气象台各层次天气图","deadline":"03:30"},{"serial":8,"title":"运行区域内热带气旋和火山动态","deadline":"03:30"},{"serial":9,"title":"鄂州机场预报质量评定","deadline":"03:30"}]},"dawn":{"id":"dawn","label":"每日 03:00–09:00","items":[{"serial":1,"title":"发布未来4小时天气预报/向签派放行带班席提供04-09时天气梳理结果（可同该时段预报）","deadline":"04:00"},{"serial":2,"title":"检查00UTC低空重要天气预告图","deadline":"04:50"},{"serial":3,"title":"通报全国雷达拼图至丰声“航空气象信息通报群”，并通知运行控制带班","deadline":"06:30"},{"serial":4,"title":"检查06UTC中高层重要天气预告图、高空风和温度预告图","deadline":"07:50"},{"serial":5,"title":"发布未来12小时天气预报","deadline":"08:00"},{"serial":6,"title":"制作并讲解天气分析材料，同步维护飞行运作网简报","deadline":"09:00"},{"serial":7,"title":"运行区域内热带气旋和火山动态","deadline":"09:00"},{"serial":8,"title":"使用早会讲评分析材料进行席位交接，确认已交接以下内容：日常事务、天气系统的演变、天气过程的概述、重点评估机场","deadline":"09:00"}]}}};
